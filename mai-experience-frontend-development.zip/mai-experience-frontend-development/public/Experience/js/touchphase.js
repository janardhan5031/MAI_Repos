export const TouchPhase = {
    None: 0,
    Began: 1,
    Moved: 2,
    Ended: 3,
    Canceled: 4,
    Stationary: 5
  };
