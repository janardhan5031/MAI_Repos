export const HOME = "/";
export const LOGIN = "/login";
export const AUTH = "/data-channel";
export const SIGNUP = "/signup";
export const FORGOT_PASSWORD = "/forgot-password";
