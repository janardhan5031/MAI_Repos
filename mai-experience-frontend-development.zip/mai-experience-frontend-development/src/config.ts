export const CONFIG = {
  ATTENDEE_LINK: "https://dev-maya-event.p2eppl.com",
  ORG_LINK: "https://dev-popsevent.p2eppl.com",
  VENDOR_LINK: "https://dev-popsmerch.p2eppl.com",
  GRAPHQL_ENDPOINT: "https://dev-mai-experienceapi.p2eppl.com/graphql",
  ENDPOINT_LINK: "https://dev-maya-event.p2eppl.com",
  // SIGNALING_SERVER: "maya-unity.p2eppl.com",
  SIGNALING_SERVER: "13.233.168.224",
  SIGNELLING_SERVER_HOE: "unity-qa-hoe.p2eppl.com",
  SIGNELLING_SERVER_HOP: "unity-qa-hop.p2eppl.com",
  AGORA_APP_KEY: "411066659#1245222",
  MALE_AVATAR:
    "https://poc-pops.s3.ap-south-1.amazonaws.com/assets/avatar-male-chat.png",
  FEMALE_AVATAR:
    "https://poc-pops.s3.ap-south-1.amazonaws.com/assets/avatar-female-chat.png",
};
//https://dev-mai-exp-signalapi.p2eppl.com/
//13.233.168.224
