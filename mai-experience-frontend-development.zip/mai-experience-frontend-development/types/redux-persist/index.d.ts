declare module "redux-persist/lib/integration/react";
declare module "redux-persist/es/persistStore";
declare module "redux-persist/es/persistReducer";
declare module "redux-persist/lib/storage";
declare namespace React {
  type StatelessComponent<P> = React.FunctionComponent<P>;
}
