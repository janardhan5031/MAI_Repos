export const HOME = "/";
export const CONFIGURATOR = "/configurator";
export const LOGIN = "/login";
export const SIGNUP = "/signup";
