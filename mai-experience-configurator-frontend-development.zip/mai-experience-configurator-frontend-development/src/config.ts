export const CONFIG = {
  API_ENDPOINT: "https://dev-mai-experienceapi.p2eppl.com/graphql",
  ENDPOINT_LINK: "https://dev-popsevent.p2eppl.com",
  CONFIGURATORPAGE_LINK:
    "https://mai-events-configurator-builds.s3.ap-south-1.amazonaws.com/common-qa/v37/Builds/Build/",
  ASSET_LINK:
    "https://mai-events-configurator-builds.s3.ap-south-1.amazonaws.com/common-qa/v37/Builds/",
  HOMEPAGE_LINK:
    "https://poc-pops.s3.ap-south-1.amazonaws.com/preview/Builds/Build/",
};
