export const imageMimeTypes = ["image/jpeg", "image/jpg", "image/png"];

export const videoMimeTypes = ["video/mp4"];

export const audioMimeTypes = [
  "audio/wav",
  "audio/ogg",
  "audio/mp3",
  "audio/mpeg",
];
