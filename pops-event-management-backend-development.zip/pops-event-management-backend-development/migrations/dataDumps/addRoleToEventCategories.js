module.exports = [
    { eventCategory: 'Comedy Show', role: 'Artist' },
    { eventCategory: 'Conference', role: 'Speaker' },
    { eventCategory: 'Talks', role: 'Speaker' },
    { eventCategory: 'Workshops', role: 'Instructor' },
    { eventCategory: 'Meetups', role: 'Host' },
    { eventCategory: 'Music Festival', role: 'Artist' },
    { eventCategory: 'Concert', role: 'Artist' },
    { eventCategory: 'Exhibition', role: 'Artist' },
    { eventCategory: 'Fashion Show', role: 'Designer' }
  ];
