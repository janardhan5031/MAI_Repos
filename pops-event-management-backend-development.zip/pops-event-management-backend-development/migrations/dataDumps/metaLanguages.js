const { ObjectId } = require("mongodb");

module.exports = [
  {
    _id: new ObjectId("64f80d237190966184636eef"),
    language: "English",
  },
  {
    _id: new ObjectId("65152b4c9687b28522a2ae14"),
    language: "Vietnamese",
  },
  {
    _id: new ObjectId("65152b439687b28522a2ae13"),
    language: "Hindi",
  },
];
